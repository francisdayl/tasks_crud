def get_user_id_from_auth(authorization: str):
    return "67e791553a9fd66829584088"
